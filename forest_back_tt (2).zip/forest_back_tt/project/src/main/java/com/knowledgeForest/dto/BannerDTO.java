package com.knowledgeForest.dto;

public class BannerDTO {

}
